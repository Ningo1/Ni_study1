package rugeekbrains.Ni1;

public class HomeWork2Too {
    public static void main(String[] args) {
        checkStrok(5);
    }

    public static void checkStrok(int k){
         for (int i = 1; i <= k; i++) {
            System.out.println("Строка");
         }
     }
}
