package rugeekbrains.Ni1;

public class NewHomeWorkNi {
    public static void main(String[] args) {
        System.out.println(checkSum(10, 5));
    }

    public static boolean checkSum(int a, int b) {
        if (a + b >= 10 && a + b <= 20) {
            return true;
        } else {
            return false;
        }
    }

//t/e/st
}


