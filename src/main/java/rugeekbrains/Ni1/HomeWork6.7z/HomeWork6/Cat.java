package rugeekbrains.Ni1.HomeWork6;

public class Cat extends Animals {


    public Cat(String name, String color, int dl) {
        super(name, color);

    }
}
