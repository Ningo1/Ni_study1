package rugeekbrains.Ni1.HomeWork6;

public class Dog extends Animals{

    public Dog(String name, String color) {
        super(name, color);
    }
}

